<?php
/**
 * DokuWiki Plugin selfmeasurement (Syntax Component)
 *
 * @license BSD-3 Clause http://www.gnu.org/licenses/bsd.html
 * @author  Eric Maeker, MD (fr) <eric.maeker@gmail.com>
 */

$meta['automeasurement_sendto']      = array('email');

//Setup VIM: ex: et ts=2 enc=utf-8 :

