<?php
/**
 * DokuWiki Plugin selfmeasurement (Syntax Component)
 *
 * @license BSD-3 Clause http://www.gnu.org/licenses/bsd.html
 * @author  Eric Maeker, MD (fr) <eric.maeker@gmail.com>
 */

$conf['automeasurement_sendto'] = ""; // mail to use for the report sending
